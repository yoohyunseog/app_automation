import streamlit as st
import streamlit.components.v1 as components
import sys
import tempfile

from components.nb_chart import render_nb_chart
from components.signal_badge import render_signal_badge
from blog_automation.naver_login import (
    naver_login,
    after_login_action,
    is_driver_alive,
    is_logged_in,
    load_credentials,
    save_credentials,
    go_to_write_page
)
from components.naver_blog_login_ui import render_blog_ui
from components.blog_automation import render_write_ui
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import WebDriverException
from datetime import datetime
import os

_driver = None
LAUNCH_LOG = "../data/selenium_chrome_launch_time.txt"  # 실행 정보 저장 파일

def get_driver(headless=False):  # headless=False로 설정
    global _driver

    # 기존 드라이버가 살아있는지 확인하고, 살아있으면 종료
    if _driver is not None:
        try:
            if _driver.window_handles:
                _driver.quit()  # 기존 드라이버 종료
        except WebDriverException:
            pass  # 드라이버가 정상적으로 종료되지 않으면 새로 시작

    # 크롬 드라이버 설정
    chrome_path = "C:/chromedriver.exe"
    service = Service(executable_path=chrome_path)

    options = Options()
    if headless:
        options.add_argument("--headless")
    else:
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-features=site-per-process")
        options.add_argument("--disable-popup-blocking")
        options.add_argument("--disable-infobars")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)
        options.add_experimental_option("detach", True)

    # 유저 프로필 디렉토리 설정
    profile_dir = "E:/selenium_profiles/naver"
    options.add_argument(f"user-data-dir={profile_dir}")

    # 알림, 이미지 로딩 제한
    prefs = {
        "profile.default_content_setting_values.notifications": 2,
        "profile.managed_default_content_settings.images": 1
    }
    options.add_experimental_option("prefs", prefs)

    # 크롬 실행
    _driver = webdriver.Chrome(service=service, options=options)

    # 실행 로그 파일 초기화
    try:
        with open("../data/selenium_chrome_action_log.txt", "w", encoding="utf-8") as f:
            pass  # 기존 로그 비우기

        launch_time = datetime.now().isoformat()
        start_url = _driver.current_url if _driver.current_url else "N/A"

        with open(LAUNCH_LOG, 'w', encoding='utf-8') as f:
            f.write(f"launch_time: {launch_time}\n")
            f.write(f"start_url: {start_url}\n")

        print(f"📄 실행 정보 저장 완료: {LAUNCH_LOG}")
    except Exception as e:
        print(f"⚠️ 실행 정보 저장 실패: {e}")

    # 창을 맨 앞으로 가져오기
    _driver.execute_script("window.focus();")  # 자바스크립트로 창 포커스

    return _driver

def create_driver_if_needed():
    return get_driver(headless=False)  # headless=False로 설정하여 실제 브라우저 창을 띄움

# 콘솔 한글 깨짐 방지를 위한 설정 (선택사항)
sys.stdout.reconfigure(encoding='utf-8')

# 상태 메시지 설정 함수
def set_bottom_message(message: str):
    st.session_state.bottom_message = message

def main():
    st.set_page_config(page_title="N/B 분석기 with 자동화", layout="wide")

    # 세션 상태 초기화
    if "page" not in st.session_state:
        st.session_state.page = "nb"
    if "bottom_message" not in st.session_state:
        st.session_state.bottom_message = "🧾 상태 메시지: 이 영역은 항상 하단에 고정됩니다."

    # 사이드바 메뉴
    st.sidebar.markdown("## 📂 메뉴")
    menu_items = {
        "nb": "🔍 N/B 분석기",
        "blog": "📝 블로그 자동화",
        "write": "글쓰기",
        "nb_scout": "🛰 NB-Scout 자동 실행"  # ✅ 새 이름
    }

    for key, label in menu_items.items():
        if st.sidebar.button(label, key=f"menu_{key}"):
            st.session_state.page = key

    st.sidebar.markdown("---")

    # 페이지 렌더링
    if st.session_state.page == "nb":
        from apps.nb_analyzer.ui import render_nb_analysis_ui
        render_nb_analysis_ui()

    elif st.session_state.page == "blog":
        render_blog_ui()

    elif st.session_state.page == "write":
        render_write_ui(set_bottom_message)  # ✅ 메시지 설정 함수 전달

    elif st.session_state.page == "nb_scout":
        from apps.nb_scout.ui import render_nb_scout_page
        render_nb_scout_page()

    # ✅ 하단 상태 메시지 출력
    st.markdown(f"""
        <div style="
            position: fixed;
            bottom: 0px;
            left: 0px;
            width: 100%;
            height: 40px;
            background-color: rgb(231, 231, 231);
            border-top: 1px solid rgb(221, 221, 221);
            padding: 10px 20px;
            font-size: 16px;
            color: rgb(51, 51, 51);
            z-index: 9999;
            text-align: right;">
            {st.session_state.bottom_message}
        </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
